---
layout: post
title: Schedule
permalink: /schedule/
---

The workshop will be held in person on 5 June at the Informatics Forum, University of Edinburgh.

**TBD**


<!--
The Web Conference 2024 homepage for our workshop is [here](https://ai-ads.github.io/web2024/). The following schedule is based on Anywhere on Earth (AoE).

9:00--9:05AM **Opening remark:** Fengxiang He, on-site, "Online advertising in the AI era"

9:05--9:35AM **Invited talk:** Su Lin Blodgett, virtual, "Two Challenges for Equitable Language Technologies"

9:35--10:05AM **Invited talk:** Song Zuo, on-site, "Automation in Online Advertising Markets: Auctions and Efficiency"

10:05-10:35AM **Invited talk:** Maziar Gomrokchi, on-site, "AdCraft: An Advanced Reinforcement Learning Benchmark Environment for Search Engine Marketing Optimization"

10:35--11:05AM **Invited talk:** Rishabh Mehrotra, virtual, "Differential Impact on Stakeholder Outcomes on Multi-stakeholder Platforms"

11:05--11:35AM **Invited talk:** Olivier Jeunen, virtual, "Learning to Value, Bid for, and Auction Online Advertisements"

12:00--12.20PM **Contributed talk:** Yuzhu Chen, virtual, "Enhancing Diffusion Models through Intelligent Time-Stepping Optimization"

If you have any questions, please contact us via email:<br>
[ai-ads-24-chairs@googlegroups.com](mailto:ai-ads-24-chairs@googlegroups.com)
-->