---
layout: post
title: Organisers
permalink: /organisers/


---
<table>
  <tr>
    <td> 
      <img src="https://github.com/AI-Ads/web2024/blob/main/images/Fengxiang_He.jpg?raw=true"  alt="1" width = 150px height = 155px ><br />
      <a href="https://fengxianghe.github.io/">Fengxiang He</a><br />
      Edinburgh
    </td>
    <td> 
      <img src="https://github.com/AI-Ads/web2024/blob/main/images/Mengnan_Du.jpg?raw=true"  alt="1" width = 150px height = 155px ><br />
      <a href="https://www.vaishakbelle.org/">Vaishak Belle</a><br />
      Edinburgh
    </td>
    <td> 
      <img src="https://github.com/AI-Ads/web2024/blob/main/images/Aris_Filos-Ratsikas.jpg?raw=true"  alt="1" width = 150px height = 155px ><br />
      <a href="https://www.maths.ed.ac.uk/~mdecarv/">Miguel de Carvalho</a><br />
      Edinburgh
    </td>
  </tr>
  <tr>
    <td> 
      <img src="https://github.com/AI-Ads/web2024/blob/main/images/lu_cheng1.png?raw=true"  alt="1" width = 150px height = 155px ><br />
      <a href="https://sites.google.com/view/cathyychen">Cathy Yi-Hsuan Chen</a><br />
      Glasgow
    </td>
    <td> 
      <img src="https://github.com/AI-Ads/web2024/blob/main/images/Qingquan_Song.jpg?raw=true"  alt="1" width = 150px height = 155px ><br />
      <a href="https://www.macs.hw.ac.uk/~ek19/">Ekaterina Komendantskaya</a><br />
      Edinburgh
    </td>
    <!--
    <td> 
      <img src="https://github.com/AI-Ads/web2024/blob/main/images/Min_Lin.jpeg?raw=true"  alt="1" width = 150px height = 155px ><br />
      <a href="https://linmin.me/">Min Lin</a><br />
      Sea AI Lab
    </td>
    -->
   </tr>
  <!--
  <tr>  
    <td> 
      <img src="https://github.com/AI-Ads/web2024/blob/main/images/John_Vines.jpg?raw=true"  alt="1" width = 150px height = 155px ><br />
      <a href="https://www.designinformatics.org/person/john-vines/">John Vines</a><br />
      Edinburgh
    </td>
  </tr> 
  -->
</table>
