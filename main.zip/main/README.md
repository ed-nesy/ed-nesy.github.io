# AI Driven Online Advertising
Edinburgh Workshop on Neural-Symbolic AI
