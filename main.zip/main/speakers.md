---
layout: post
title: Speakers
permalink: /speakers/
---

**TBD**

<!--
<table>
  <tr>
    <td> 
      <img src="https://github.com/AI-Ads/web2024/blob/main/images/Su_Lin_Blodgett.jpg?raw=true"  alt="1" width = 150px height = 160px ><br />
      <a href="https://sblodgett.github.io/">Su Lin Blodgett</a><br />
      Microsoft Research
    </td>
    <td> 
      <img src="https://github.com/AI-Ads/web2024/blob/main/images/zuo.png?raw=true"  alt="1" width = 150px height = 160px ><br />
      <a href="https://sites.google.com/view/songzuo">Song Zuo</a><br />
      Google Research
    </td>
     <td> 
      <img src="https://github.com/AI-Ads/web2024/blob/main/images/Maziar-c.png?raw=true"  alt="1" width = 150px height = 160px ><br />
      <a href="https://maziarg.github.io/">Maziar Gomrokchi</a><br />
      Elementera
    </td>
  </tr> 
  <tr>
    <td> 
      <img src="https://github.com/AI-Ads/web2024/blob/main/images/Rishabh_pic2.jpg?raw=true"  alt="1" width = 150px height = 160px ><br />
      <a href="https://rishabhmehrotra.com/">Rishabh Mehrotra</a><br />
      Sourcegraph
    </td>
    <td> 
      <img src="https://github.com/AI-Ads/web2024/blob/main/images/olivier.png?raw=true"  alt="1" width = 150px height = 160px ><br />
      <a href="https://olivierjeunen.github.io/">Olivier Jeunen</a><br />
      ShareChat
    </td>
  </tr> 
</table>
-->
